ChangeLog
=========

2.2.0 (2013-03-22)
------------------

*Bugfix:*

    * `#1 <https://github.com/rbarrois/python-semanticversion/issues/1>`_: Allow partial
      versions without minor or patch level

*New:*

    * Add the :meth:`Version.coerce <semantic_version.Version.coerce>` class method to
      :class:`~semantic_version.Version` class for mapping arbitrary version strings to
      semver.
    * Add the :func:`~semantic_version.validate` method to validate a version
      string against the SemVer rules.
    * Full Python3 support

2.1.2 (2012-05-22)
------------------

*Bugfix:*

    * Properly validate :class:`~semantic_version.django_fields.VersionField` and
      :class:`~semantic_version.django_fields.SpecField`.

2.1.1 (2012-05-22)
------------------

*New:*

    * Add introspection rules for south

2.1.0 (2012-05-22)
------------------

*New:*

    * Add :func:`semantic_version.Spec.filter` (filter a list of :class:`~semantic_version.Version`)
    * Add :func:`semantic_version.Spec.select` (select the highest
      :class:`~semantic_version.Version` from a list)
    * Update :func:`semantic_version.Version.__repr__`

2.0.0 (2012-05-22)
------------------

*Backwards incompatible changes:*

    * Removed "loose" specification support
    * Cleanup :class:`~semantic_version.Spec` to be more intuitive.
    * Merge Spec and SpecList into :class:`~semantic_version.Spec`.
    * Remove :class:`~semantic_version.django_fields.SpecListField`

1.2.0 (2012-05-18)
------------------

*New:*

    * Allow split specifications when instantiating a
      :class:`~semantic_version.SpecList`::

            >>> SpecList('>=0.1.1', '!=0.1.3') == SpecList('>=0.1.1,!=0.1.3')
            True

1.1.0 (2012-05-18)
------------------

*New:*

    * Improved "loose" specification support (``>~``, ``<~``, ``!~``)
    * Introduced "not equal" specifications (``!=``, ``!~``)
    * :class:`~semantic_version.SpecList` class combining many :class:`~semantic_version.Spec`
    * Add :class:`~semantic_version.django_fields.SpecListField` to store a :class:`~semantic_version.SpecList`.

1.0.0 (2012-05-17)
------------------

First public release.

*New:*

    * :class:`~semantic_version.Version` and :class:`~semantic_version.Spec` classes
    * Related django fields: :class:`~semantic_version.django_fields.VersionField`
      and :class:`~semantic_version.django_fields.SpecField`

.. vim:et:ts=4:sw=4:tw=79:ft=rst:
