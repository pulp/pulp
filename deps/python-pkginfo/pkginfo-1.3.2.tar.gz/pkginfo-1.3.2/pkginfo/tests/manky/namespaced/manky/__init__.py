# Dummy package inside the 'namespaced' namespace.
