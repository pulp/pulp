.. currentmodule:: celery.contrib.sphinx

.. automodule:: celery.contrib.sphinx
    :members:
