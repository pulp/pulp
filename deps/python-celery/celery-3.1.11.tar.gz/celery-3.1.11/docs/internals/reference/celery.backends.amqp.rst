=======================================
 celery.backends.amqp
=======================================

.. contents::
    :local:
.. currentmodule:: celery.backends.amqp

.. automodule:: celery.backends.amqp
    :members:
    :undoc-members:
