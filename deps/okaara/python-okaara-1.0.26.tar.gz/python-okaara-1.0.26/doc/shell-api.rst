Interactive Shell
=================

Shell Class APIs
----------------

.. autoclass:: okaara.shell.Shell
   :members:
   :special-members:

Screen Class APIs
-----------------

.. autoclass:: okaara.shell.Screen
   :members:
   :special-members:

MenuItem Class APIs
-------------------

.. autoclass:: okaara.shell.MenuItem
   :members:
   :special-members:

Exceptions
----------

.. autoclass:: okaara.shell.Exit

