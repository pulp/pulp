git archive --format=tar.gz --prefix=python-nectar-0.90.0/ master >python-nectar-0.90.0.tar.gz
