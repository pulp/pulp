Nectar
======

Nectar is a download library that abstracts the workflow of making and tracking
download requests away from the mechanics of how those requests are carried
out. It allows multiple downloaders to exist with different implementations,
such as the default "threaded" downloader, which uses the "requests" library
with multiple threads. Other experimental downloaders have used tools like
pycurl and eventlets.

Complete Documentation
----------------------

In the works...
