Eventlet+Requests-Based Downloader
==================================

The revent downloader leverages both eventlets and the requests library. It is
optimized for speed. It provides the :ref:`downloader API <downloader_api>`.

Its major use case is downloading lots of files quickly.

