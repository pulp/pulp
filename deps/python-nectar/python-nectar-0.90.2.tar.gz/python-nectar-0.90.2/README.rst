Nectar
======

Nectar is aimed at being a performance-tuned HTTP and HTTPS download client. It 
implements a number of different downloader classes, each with their own 
strengths and weaknesses, but all having the same API. This allows developers 
to interchange different downloader implementations according to their needs.

Current Downloaders
-------------------

**Curl Downloader**

(Short description here)

**Eventlet + Requests Downloader**

(Short description here)

Complete Documentation
----------------------

(Post link to RTFD once docs are published)

