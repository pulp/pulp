Eventlet+Requests-Based Downloader
==================================
