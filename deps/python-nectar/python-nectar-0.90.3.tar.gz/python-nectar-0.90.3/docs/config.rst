Downloader Configuration Objects
================================
