Curl-Based Downloader
=====================
