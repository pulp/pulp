=====================================================
 amqp.exceptions
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.exceptions

.. automodule:: amqp.exceptions
    :members:
    :undoc-members:
