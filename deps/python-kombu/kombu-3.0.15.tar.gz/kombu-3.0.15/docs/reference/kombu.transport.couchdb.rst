.. currentmodule:: kombu.transport.couchdb

.. automodule:: kombu.transport.couchdb

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:

    Functions
    ---------

    .. autofunction:: create_message_view
