:mod:`tz_util` -- Utilities for dealing with timezones in Python
================================================================

.. automodule:: bson.tz_util
   :synopsis: Utilities for dealing with timezones in Python
   :members:
