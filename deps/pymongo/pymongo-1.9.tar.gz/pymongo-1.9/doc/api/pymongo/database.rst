:mod:`database` -- Database level operations
============================================

.. automodule:: pymongo.database
   :synopsis: Database level operations
   :members:

   .. autodata:: pymongo.OFF
   .. autodata:: pymongo.SLOW_ONLY
   .. autodata:: pymongo.ALL
