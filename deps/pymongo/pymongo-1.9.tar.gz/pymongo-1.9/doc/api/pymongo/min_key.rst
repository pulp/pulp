:mod:`min_key` -- MOVED
=======================

.. module:: pymongo.min_key

This module has been deprecated in favor of
:mod:`bson.min_key`. Please use that module instead.

.. versionchanged:: 1.9
   Deprecated.
