:mod:`master_slave_connection` -- Master-slave connection to MongoDB
====================================================================

.. automodule:: pymongo.master_slave_connection
   :synopsis: Master-slave connection to MongoDB
   :members:
