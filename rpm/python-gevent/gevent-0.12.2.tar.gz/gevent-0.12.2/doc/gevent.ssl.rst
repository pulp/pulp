gevent.ssl - SSL wrapper for socket objects
===========================================

.. automodule:: gevent.ssl
    :members: none


