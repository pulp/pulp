Cooperative socket module (gevent.socket module)
================================================

.. automodule:: gevent.socket
    :members:
    :undoc-members:

