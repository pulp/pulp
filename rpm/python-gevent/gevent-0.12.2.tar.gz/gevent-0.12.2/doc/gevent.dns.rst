Synchronous wrappers around libevent-dns
========================================

.. automodule:: gevent.dns
    :members:
    :undoc-members:

