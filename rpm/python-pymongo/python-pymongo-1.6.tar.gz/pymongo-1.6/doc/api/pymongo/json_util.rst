:mod:`json_util` -- Tools for using Python's :mod:`json` module with MongoDB documents
======================================================================================
.. versionadded:: 1.1.1

.. automodule:: pymongo.json_util
   :synopsis: Tools for using Python's json module with MongoDB documents
   :members:
   :undoc-members:
