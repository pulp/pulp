:mod:`bson` -- Tools for working with `BSON <http://www.mongodb.org/display/DOCS/BSON>`_ in Python
==================================================================================================

.. automodule:: pymongo.bson
   :synopsis: Tools for working with BSON in Python
   :members:
   :show-inheritance:
