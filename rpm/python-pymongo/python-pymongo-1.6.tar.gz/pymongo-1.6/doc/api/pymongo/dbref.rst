:mod:`dbref` -- Tools for manipulating DBRefs (references to documents stored in MongoDB)
=========================================================================================

.. automodule:: pymongo.dbref
   :synopsis: Tools for manipulating DBRefs (references to documents stored in MongoDB)
   :members:
