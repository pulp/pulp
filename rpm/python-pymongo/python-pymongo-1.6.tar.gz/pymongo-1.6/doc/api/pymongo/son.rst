:mod:`son` -- Tools for working with SON, an ordered mapping
============================================================

.. automodule:: pymongo.son
   :synopsis: Tools for working with SON, an ordered mapping
   :members:
