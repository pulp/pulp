:mod:`code` -- Tools for representing JavaScript code to be evaluated by MongoDB
================================================================================

.. automodule:: pymongo.code
   :synopsis: Tools for representing JavaScript code to be evaluated by MongoDB

   .. autoclass:: Code(code[, scope=None])
      :members:
      :show-inheritance:
